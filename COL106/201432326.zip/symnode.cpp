/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "symnode.h"
//#include<iostream>
//Write your code below this line

SymNode::SymNode(){

}
//int hieght_h()
SymNode::SymNode(string k){
    key = k;
    left = NULL;
    right = NULL;
    par = NULL;
    //address = NULL;
}
SymNode* SymNode::LeftLeftRotation(){
    //SymNode* x = new SymNode(key);
}
SymNode* SymNode::RightRightRotation(){
    //key = left->key;
    //SymNode* y = new SymNode(key);
}

SymNode* SymNode::LeftRightRotation(){
    SymNode* newnode = right->RightRightRotation();
    newnode = newnode->LeftLeftRotation();
    //SymNode* newnode = new SymNode(key);
    return newnode;
}

SymNode* SymNode::RightLeftRotation(){
    SymNode* newnode = left->LeftLeftRotation();
    newnode = RightRightRotation();
    //SymNode* newnode = new SymNode(key);
    return newnode;
}

SymNode::~SymNode(){

}