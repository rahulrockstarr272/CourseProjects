/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "symtable.h"
//#include<queue>
//#include<iostream>
//Write your code below this line

SymbolTable::SymbolTable(){
    size = 0;
}
int height_(SymNode* root){
    if (root == NULL){
        return -1;
    }else{
        return 1+max(height_(root->left),height_(root->right));
    }
}
int max(int a, int b){ 
    return (a > b)? a : b;  
}  
int getBalance(SymNode *N){ 
    if (N == NULL)  
        return 0;  
    return height_(N->left) - height_(N->right);  
}  
SymNode* rightrotate(SymNode* n2){
    SymNode* n1 = n2->left;  
    SymNode* node = n1->right;  
  
    // Perform rotation  
    n1->right = n2;  
    n2->left = node;  
  
    // Update heights  
    n2->height = max(height_(n2->left), 
                    height_(n2->right)) + 1;  
    n1->height = max(height_(n1->left), 
                    height_(n1->right)) + 1;  
  
    // Return new root  
    return n1;
}
SymNode* leftrotate(SymNode* n1){
    SymNode* n2 = n1->right;  
    SymNode* node = n2->left;  
  
    // Perform rotation  
    n2->left = n1;  
    n1->right = node;  
  
    // Update heights  
    n1->height = max(height_(n1->left),height_(n1->right)) + 1;      
                    
    n2->height = max(height_(n2->left),height_(n2->right)) + 1;   
                    
  
    // Return new root  
    return n2; 
}
SymNode* insert_helper(SymNode* &node,string key){
    if (node == NULL){
        SymNode* newNode = new SymNode(key);
        newNode->height = 1;
        return(newNode);  
    }
    if (key < node->key){  
        node->left = insert_helper(node->left, key);
    }  
    else if (key > node->key){  
        node->right = insert_helper(node->right, key); 
    } 
    else{ 
        return node;  
    }
    node->height = 1 + max(height_(node->left),height_(node->right));   
    int balance = getBalance(node);  
    if (balance > 1 && key < node->left->key){
        return rightrotate(node);  
    } 
    if (balance < -1 && key > node->right->key){  
        return leftrotate(node);  
    }
    if (balance > 1 && key > node->left->key){ 
        node->left = leftrotate(node->left);  
        return rightrotate(node);  
    }  
    if (balance < -1 && key < node->right->key){
        node->right = rightrotate(node->right);  
        return leftrotate(node);  
    }  
  
    return node; 
}
//LR = DOUBLE LEFT , RL = DOUBLE RIGHT;
void SymbolTable::insert(string k){
    root = insert_helper(root,k);
    //balance(root);
    size++;
}
// Helper function to find the node with the smallest key in a tree
SymNode* minValueNode(SymNode* node) {
    SymNode* current = node;
    while (current->left != NULL) {
        current = current->left;
    }
    return current;
}

SymNode* removeNode(SymNode* root, string k) {
    if (root == NULL) {
        return root;
    }
    if (k < root->key) {
        root->left = removeNode(root->left, k);
    } else if (k > root->key) {
        root->right = removeNode(root->right, k);
    } else {
        // This is the node to be deleted
        if (root->left == NULL || root->right == NULL) {
            // Node with only one child or no child
            SymNode* temp = root->left ? root->left : root->right;

            if (temp == NULL) {
                // Node with no child
                temp = root;
                root = NULL;
            } else {
                // Node with one child
                *root = *temp; // Copy the contents of the child to the root
            }

            delete temp;
        } else {
           
            SymNode* temp = minValueNode(root->right);

            // Copy the inorder successor's data to this node
            root->key = temp->key;

            // Delete the inorder successor
            root->right = removeNode(root->right, temp->key);
        }
    }

    // If the tree had only one node, then return
    if (root == NULL) {
        return root;
    }

    // Update height of the current node
    root->height = 1 + max(height_(root->left), height_(root->right));

    // Balance the tree
    int balance = getBalance(root);

    // Left Heavy
    if (balance > 1) {
        if (getBalance(root->left) >= 0) {
            return rightrotate(root);
        } else {
            root->left = leftrotate(root->left);
            return rightrotate(root);
        }
    }

    // Right Heavy
    if (balance < -1) {
        if (getBalance(root->right) <= 0) {
            return leftrotate(root);
        } else {
            root->right = rightrotate(root->right);
            return leftrotate(root);
        }
    }

    return root;
}


void SymbolTable::remove(string k){
    root = removeNode(root,k);
    size--;
}

int SymbolTable::search(string k){
    SymNode* curr = get_root();
    while (curr!=NULL && curr->key != k){
        if (curr->key > k){
            curr = curr->left;
        }else{
            curr = curr->right;
        }
    }
    return (curr != NULL) ? curr->address : -2;
}

void SymbolTable::assign_address(string k,int idx){
    SymNode* curr = get_root();
    while (curr!=NULL && curr->key != k){
        if (curr->key > k){
            curr = curr->left;
        }else{
            curr = curr->right;
        }
    }
    curr->address = idx;
}

int SymbolTable::get_size(){
    return size;
}

SymNode* SymbolTable::get_root(){
    return root;
}

SymbolTable::~SymbolTable(){
    size = 0;
    delete root;
}
// void first_breath(SymNode* root){
//     queue<SymNode*> q;
//     if (root == nullptr){
//         return;
//     }
//     q.push(root);
//     while (!q.empty()){
//         SymNode* node = q.front();
//         q.pop();
//         std::cout<<node->key<<" ";
//         if (node->left != nullptr){
//             q.push(node->left);
//         }
//         if (node->right != nullptr){
//             q.push(node->right);
//         }
//     }
//     //return q;
// }
// int main(){
//     cout<<1<<endl;
//     SymbolTable* t = new SymbolTable();
//     t->insert("d");
//     t->insert("f");
//     t->insert("a");
//     t->insert("g");
//     //t->assign_address("g",4);
//     //cout<<t->search("g");
//     t->insert("c");
//     t->insert("z");
//     t->insert("k");
//     t->insert("l");
//      //first_breath(t->get_root());
//     t->remove("g");
//     t->remove("k");
//     t->remove("d");
//     //t->remove("z");
//     t->remove("f");
//     std::cout<<t->get_root()->height<<endl;
//     first_breath(t->get_root());
//     //cout<<t->get_root()->left->left->height - t->get_root()->left->right->height<<endl;
//     //t->insert("a");
//     return 0;
// }