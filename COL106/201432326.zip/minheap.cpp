/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "minheap.h"
//#include<iostream>
//include<queue>
//Write your code below this line 
// use size as index as seen in heap array
class heapstack{
    public:
    int* arr;
    int capacity = 1024;
    int size_ = 0;
    heapstack(){
        arr = new int[1024];
    }
    void push(int val){
        if (size_!=capacity){
            arr[size_] = val;
            size_++;
        }else{
            capacity = 2*capacity;
            int* temp = new int[capacity];
            for (int i = 0;i<size_;i++){
                temp[i] = arr[i];
            }
            delete[] arr;
            arr = temp;
            arr[size_] = val;
            size_++;
        }
    }
    void pop(){
        size_--;
    }
    int top(){
        return arr[size_-1];
    }
    int size(){
        return size_;
    }
    bool empty(){
        return size_ == 0;
    }
    void swap(int i1,int i2){
        int v1 = arr[i1];
        int v2 = arr[i2];
        arr[i1] = v2;
        arr[i2] = v1;
    }
    void heapifyup(int idx){
        if (idx == 0) return;
        int parentindex = (idx - 1)/2;
        if (arr[parentindex] > arr[idx]){
            swap(idx,parentindex);
            heapifyup(parentindex);
        }
    }
    void insert(int val){
        push(val);
        heapifyup(size_-1);
    }
};
class stack{
    public:
    HeapNode** ar;
    int capacity = 1024;
    int size_ = 0;
    stack(){
        ar = new HeapNode*[1024];
    }
    void push(HeapNode* val){
        if (size_!=capacity){
            ar[size_] = val;
            size_++;
        }else{
            capacity = 2*capacity;
            HeapNode** temp = new HeapNode*[capacity];
            for (int i = 0;i<size_;i++){
                temp[i] = ar[i];
            }
            delete[] ar;
            ar = temp;
            ar[size_] = val;
            size_++;
        }
    }
    void pop(){
        size_--;
    }
    HeapNode* top(){
        return ar[size_-1];
    }
    int size(){
        return size_;
    }
    bool empty(){
        return size_ == 0;
    }
    void swap(int i1,int i2){
        int v1 = ar[i1]->val;
        int v2 = ar[i2]->val;
        ar[i1]->val = v2;
        ar[i2]->val = v1;
    }
};
MinHeap::MinHeap(){

} 
//helper function1
heapstack* s = new heapstack();
HeapNode* buildheap(heapstack* s){
    if (s->empty()) {
        return NULL;
    }

    HeapNode* root_ = new HeapNode(s->arr[0]);
    stack* st = new stack();
    st->push(root_);
    int index = 1;

    while (!st->empty() && index < s->size()) {
        HeapNode* node = st->top();

        int leftVal = s->arr[index];
        index++;
        if (leftVal != -1) {
            node->left = new HeapNode(leftVal);
            st->push(node->left);
        } else {
            st->pop(); // Remove the current node from the stack if left child is NULL.
        }

        if (index < s->size()) {
            int rightVal = s->arr[index];
            index++;
            if (rightVal != -1) {
                node->right = new HeapNode(rightVal);
                st->push(node->right);
            }
        }
    }

    return root_;
}
void MinHeap::push_heap(int num){
    s->insert(num);
    root = buildheap(s);
    size++;
}

int MinHeap::get_min(){
    return root->val;
}
void MinHeap::pop() {
    s->pop();
    if (s->empty()) {
        root = NULL;
    } else {
        root = buildheap(s);
    }
    size--;
}

MinHeap::~MinHeap(){
}
