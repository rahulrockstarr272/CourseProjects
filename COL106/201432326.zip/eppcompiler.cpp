/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "eppcompiler.h"

//Write your code below this line
EPPCompiler::EPPCompiler(){
    memory_size = 10000001;
    mem_loc.resize(memory_size);
}
// int evalhelper(ExprTreeNode* rootnode){
//         if(rootnode==NULL) return -1;  //ana to nahi chahiye
//         else if(rootnode->type=="VAL"){
//            // cout<<1<<endl;
//             return rootnode->num;
//         }
//         else if(rootnode->type=="VAR"){
//            // cout<<2<<endl;
//             int result=rootnode->num;
//             return  result;
//         }
//         else { // node is an operator;
//             string op=rootnode->type;
//             int leftresult=evalhelper(rootnode->left);
//             int rightresult=evalhelper(rootnode->right);
//             int result;
//             if(op=="ADD"){
//                 //cout<<"add"<<endl;
//                 //cout<<leftresult->get_frac_str();
//                 result = leftresult+rightresult;
//             }
//             else if(op=="SUB"){
//                 result=leftresult-rightresult;
//             }
//             else if(op=="MUL"){
//                 //cout<<"mul"<<endl;
//                 result=leftresult*rightresult;
//             }
//             else if(op=="DIV"){
//                 result = leftresult/rightresult;
//             }
//             rootnode->num=result;
//             // cout<<rootnode->evaluated_value->get_frac_str()<<endl;
//             return result;
//         }
//         return -1;

// }
     //Parser targ;    stores target language
//   int memory_size;   number of variables
//   string output_file;  command in string
//   vector<int> mem_loc;
//   MinHeap least_mem_loc;
EPPCompiler::EPPCompiler(string out_file,int mem_limit){
    memory_size = 10000001;
    mem_loc.resize(memory_size  );
    output_file = out_file;
    memory_size = mem_limit;
}
//helper function for generating command
void write_command(ExprTreeNode* root,string &file,Parser p,vector<int> mem){
    static std::ofstream outfile(file);
    static ExprTreeNode* copy = root;
    //root taken at right so no equal..
    if (root==NULL){
        outfile.close();
        return;
    }
    write_command(root->right,file,p,mem);
    if (copy->left == root->right && copy->right == root->right){
        //k++;
        //mem.push_back(k);
        outfile<<"mem["+std::to_string(mem.size())+"] = POP"<<std::endl;
    }
    write_command(root->left,file,p,mem);
    if (root->type == "VAL"){
        outfile<<"PUSH"<<" "+root->id<<std::endl;
    }else if (root->type == "ADD"){
        outfile<<"ADD"<<std::endl;
    }else if (root->type == "MUL"){
        outfile<<"MUL"<<std::endl;
    }else if (root->type == "DIV"){
        outfile<<"DIV"<<std::endl;
    }else if (root->type == "SUB"){
        outfile<<"SUB"<<std::endl;
    }else{
        outfile<<"PUSH"<<+"mem["+std::to_string(mem[p.symtable->search(root->id)])+"]"<<std::endl;
    }
}
//to do:add targ code to output_file
void EPPCompiler::compile(vector<vector<string>> code){
    int k = 0;
    for (int i=0;i<code.size();i++){
        targ.parse(code[i]); 
        if (targ.expr_trees[i]->left->type == "VAR"){ 
            mem_loc.push_back(k);
            targ.symtable->assign_address(code[i][0],k);
            write_command(targ.expr_trees[i],output_file,targ,mem_loc);
            //mem_loc.erase(mem_loc.begin());
            k++;
        }else if (targ.expr_trees[i]->left->type == "DEL"){
            int idx = targ.symtable->search(code[i][2]);    //index to be removed
            targ.symtable->remove(targ.expr_trees[i]->right->id);
            int addr = targ.symtable->search(code[i][0]);
            //mem_loc.erase(std::remove(mem_loc.begin(),mem_loc.end(), addr), mem_loc.end());
            write_command(targ.expr_trees[i],output_file,targ,mem_loc);
            mem_loc[addr] = -1;   //means no variable here at this memory address
            //mem_loc.push_back(k)
        }
    }

}

vector<string> EPPCompiler::generate_targ_commands(){
    vector<string> commands;
    ExprTreeNode* last = targ.expr_trees[targ.expr_trees.size()-1];
    //generate target commands for last symnode in symtable:

}

void EPPCompiler::write_to_file(vector<string> commands){

}

EPPCompiler::~EPPCompiler(){
  
}
