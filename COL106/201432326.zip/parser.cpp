/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "parser.h"
//#include<queue>
//#include<iostream>
class Stack {
public:
    std::vector<ExprTreeNode*> stack;
    ~Stack(){           //n after +2
    }
  

    void push(ExprTreeNode* node) {
        stack.push_back(node);
    }

    ExprTreeNode* pop() {
        if (!stack.empty()) {
            ExprTreeNode* top = stack.back();
            stack.pop_back();
            return top;
        }
        return nullptr; 
    }
};
bool isInteger(const std::string& str) {
    for (char c : str) {
        if (!std::isdigit(c)) {
            return false;
        }
    }
    return true;
}
//Write your code below this line
//helper function to evaluate expression value
void buildParseTree(const std::vector<std::string>& tokens,ExprTreeNode* &currentTree,SymbolTable* symtable) {
    Stack pStack;
    currentTree= new ExprTreeNode();
    //ExprTreeNode* top = currentTree;   //n
    pStack.push(currentTree);
    if (tokens.size()!=0){
        if (tokens[0]!="del" || tokens[0]!="ret"){
            currentTree->id = ":=";
            currentTree->type = "equal";
            currentTree->left = new ExprTreeNode();
            currentTree->left->id = tokens[0];
            currentTree->left->type = "VAR";
            symtable->insert(tokens[0]);     //new
            currentTree->right = new ExprTreeNode();
            currentTree = currentTree->right;
            vector<string> tokensU(tokens.begin()+2,tokens.end());
            for (const std::string& token : tokensU) {
                if (token == "(") {
                    currentTree->left = new ExprTreeNode();
                    pStack.push(currentTree);
                    currentTree = currentTree->left;
                } else if (token == "+" || token == "-" || token == "*" || token == "/") {
                    //cout<<"here"<<endl;
                    currentTree->id = token;
                    currentTree->right = new ExprTreeNode();
                    if (token == "+"){
                        currentTree->type = "ADD";
                    }else if (token == "-"){
                        currentTree->type = "SUB";
                    }
                    else if (token == "*"){
                        currentTree->type = "MUL";
                    }
                    else if (token == "/"){
                        currentTree->type = "DIV";
                    }
                    pStack.push(currentTree);
                    currentTree = currentTree->right;
                } else if (token == ")") {
                    currentTree = pStack.pop();
                } else if (token != "+" && token != "-" && token != "*" && token != "/" && token != ")") {
                    if (isInteger(token)){
                        //cout<<"here";
                        
                    
                            // UnlimitedInt* num = new UnlimitedInt(token);
                            // UnlimitedInt* one = new UnlimitedInt("1");
                            // UnlimitedRational* value = new UnlimitedRational(num,one);
                            currentTree->type = "VAL";
                            currentTree->id = token;
                            currentTree->num = std::stoi(token);
                            currentTree = pStack.pop();

                    }else{
                        currentTree->type = "VAR";
                        currentTree->id = token;
                        //currentTree->num = symtable->search(token);   //they'll handle this
                        currentTree = pStack.pop();
                    }

                }
            }
            //first_breath(eTree);
            //top->left->num = evalhelper(top->right);
            return;
        }else if (tokens[0]=="del"){
            currentTree->left = new ExprTreeNode();
            currentTree->right = new ExprTreeNode();
            currentTree->left->type = "DEL";
            currentTree->left->id = "'DEL";
            currentTree->type = "EQUAL";
            currentTree->id = ":=";
            currentTree->right->type = "VAR";
            currentTree->right->id  = tokens[2];
            //currentTree->right->num = symtable->search(tokens[2]);
            //symtable->remove(tokens[2]);
        }else{
            currentTree->left = new ExprTreeNode();
            currentTree->right = new ExprTreeNode();
            currentTree->left->type = "RET";
            currentTree->left->id = "'RET";
            currentTree->type = "EQUAL";
            currentTree->id = ":=";
            currentTree = currentTree->right;
            vector<string> tokensU(tokens.begin()+2,tokens.end());
            for (const std::string& token : tokensU) {
                if (token == "(") {
                    currentTree->left = new ExprTreeNode();
                    pStack.push(currentTree);
                    currentTree = currentTree->left;
                } else if (token == "+" || token == "-" || token == "*" || token == "/") {
                    //cout<<"here"<<endl;
                    currentTree->id = token;
                    currentTree->right = new ExprTreeNode();
                    if (token == "+"){
                        currentTree->type = "ADD";
                    }else if (token == "-"){
                        currentTree->type = "SUB";
                    }
                    else if (token == "*"){
                        currentTree->type = "MUL";
                    }
                    else if (token == "/"){
                        currentTree->type = "DIV";
                    }
                    pStack.push(currentTree);
                    currentTree = currentTree->right;
                } else if (token == ")") {
                    currentTree = pStack.pop();
                } else if (token != "+" && token != "-" && token != "*" && token != "/" && token != ")") {
                    if (isInteger(token)){
                        //cout<<"here";
                        
                    
                            // UnlimitedInt* num = new UnlimitedInt(token);
                            // UnlimitedInt* one = new UnlimitedInt("1");
                            // UnlimitedRational* value = new UnlimitedRational(num,one);
                            currentTree->type = "VAL";
                            currentTree->id = token;
                            currentTree->num = std::stoi(token);
                            currentTree = pStack.pop();

                    }else{
                        currentTree->type = "VAR";
                        currentTree->id = token;
                        //currentTree->num = symtable->search(token);   //they'll handle this
                        currentTree = pStack.pop();
                    }

                }
            }
            //first_breath(eTree);
            //top->left->num = evalhelper(top->right);
            return;
        }

    }else{
        //top->left->num = evalhelper(top->right);
        return;
    }
}
Parser::Parser(){

}

void Parser::parse(vector<string> expression){
    ExprTreeNode* root;
    //int i = 0;
    buildParseTree(expression,root,symtable);
    expr_trees.push_back(root);
}

Parser::~Parser(){
  
}
// void first_breath(ExprTreeNode* root){
//     queue<ExprTreeNode*> q;
//     if (root == nullptr){
//         return;
//     }
//     q.push(root);
//     while (!q.empty()){
//         ExprTreeNode* node = q.front();
//         q.pop();
//         cout<<node->id<<" ";
//         if (node->left != nullptr){
//             q.push(node->left);
//         }
//         if (node->right != nullptr){
//             q.push(node->right);
//         }
//     }
//     //return q;
// }
// int main(){
//     vector<string> v = {"del",":=","x"};
//     Parser p;
//     p.parse(v);
//     first_breath(p.expr_trees[0]);
//     return 0;
// }