// Do NOT add any other includes
#include "search.h"
#include "dict.h"
#define d 256
#define z 13
node::node(int book, int pag, int para, int set, std::string sencent) {
  bookno = book;
  page = pag;
  paragrap = para;
  sentno = set;
  sentence = sencent;
}
SearchEngine::SearchEngine() {
  // Implement your function here
  
}
Dict dictionary_tool;
SearchEngine::~SearchEngine() {
  // Implement your function here
}
vector<node*> SearchEngine::get_sentences(){
  return sentences;
}
void SearchEngine::insert_sentencee(int book_code, int page, int paragraph,
                                   int sentence_no, string sentence) {
  // Implement your function here
  node* newnode = new node(book_code, page, paragraph, sentence_no, sentence);//offset = -1
  sentences.push_back(newnode);
  //dictionary_tool.insert_sentenc(book_code,page,paragraph,sentence_no,sentence);
  return;
}
bool is_seperatorr(char c){
    string sep = ".,-:!\"|\'()?-[]“” ‘’˙;@";
    for (char ch:sep){
        if (ch == c){
            return true;
        }
    }
    return false;
}
bool search(vector<string> words,string p){
  for (string word:words){
    if (word == p){
      return true;
    }
  }
  return false;
}
vector<string> word(string question){
  vector<string> words;
  string shabd = "";
  int track = 0;
  for (char c:question){
    track++;
    if (!is_seperatorr(c)){
      shabd += c;
      if (track == question.size() && !search(words,shabd) && shabd.size() != 0){
        words.push_back(shabd);
      }
    }else{
      if (shabd.size() != 0 && !search(words,shabd)){
        words.push_back(shabd);
        shabd = "";
      }
      shabd = "";
    }
  }
  return words;
}
vector<vector<int>> SearchEngine::search(string question) {   //RETURNS <paragraph,score(p)>
}