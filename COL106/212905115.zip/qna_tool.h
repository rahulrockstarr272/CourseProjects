#pragma once
#include <iostream>
#include <fstream>
#include "Node.h"
#include "dict.h"
#include "search.h"

using namespace std;
class paragraph_node{
    public:
    int bookcode;
    int page;
    int sentence_no;
    int paragraph;
    string sentence;
    double scorep;
};
class maxheap{
    public:
    vector<paragraph_node> arr;
    // long long capacity = 1024*1024;
    int size = 0;
    size_t maxSize;
    maxheap(){
        //arr = new paragraph_node[capacity];
    }
    void heapifyup(int idx){
        if (idx == 0){
            return;
        }
        int parent = (idx-1)/2;
        if (arr[parent].scorep < arr[idx].scorep){
            swap(parent,idx);
            heapifyup(parent);
        }
    }
    void heapifydown(int idx){
        while (true) {
            size_t leftChild = 2 * idx + 1;
            size_t rightChild = 2 * idx + 2;
            size_t largest = idx;

            if (leftChild < arr.size() && arr[leftChild].scorep > arr[largest].scorep) {
                largest = leftChild;
            }

            if (rightChild < arr.size() && arr[rightChild].scorep > arr[largest].scorep) {
                largest = rightChild;
            }

            if (largest != idx) {
                swap(idx,largest);
                idx = largest;
            } else {
                break;
            }
        }
    }
    void swap(int i1,int i2){
        paragraph_node n1 = arr[i1];
        paragraph_node n2 = arr[i2];
        arr[i1] = n2;
        arr[i2] = n1;
    }
    void insert(paragraph_node n){
        // if (arr.size() > maxSize){
            arr.push_back(n);
            heapifyup(arr.size()-1);
            //size++;
        // }else{
        //     if (n.scorep < arr.front().scorep) {
        //         arr[0] = n;
        //         heapifydown(0);
        //     }
        // }
    }
    void pop(){
        swap(0,arr.size()-1);
        arr.pop_back();
        //int n = arr.size();
        heapifydown(0);
        // for (int i=n-1;i<-1;i++){
        //     heapifyup(i);
        // }
    }
    paragraph_node top(){
        return arr[0]; // max value
    }
};
class qNode{                  //useless
    public:
        int bookno;
        int page;
        int paragrap;
        int sentno;
        string sentence;
        qNode(int book,int pag,int para,int set, std::string sencent){
            bookno = book;
            page = pag;
            paragrap = para;
            sentno = set;
            sentence = sencent;
        }
        //int linersearch(std::string pattern);

};
class trie_node{
    public:
    char ch;
    long long count=0;
    trie_node* childrens[254]; // 0 to 25 alphabets 26 to 35 numbers childrens[26] = 0; //n /,&=ke liye increse
    bool eof=false;           // 26=0 35=9 36=& 37=/ 38=_=isse bhi dalna hai <> = 39 40
    bool isword = false;
    vector<vector<int>> corpus; //{page,para,sentenceno}
    trie_node(){
        ch = ' ';
        for (int i=0;i<254;i++){
            childrens[i]=NULL;
        }
    }
    trie_node(char c){
        ch = c;
        for (int i=0;i<254;i++){
            childrens[i]=NULL;
        }
    }
    ~trie_node(){
        for (int i = 0;i<254;i++){
            if (childrens[i]!=NULL){
                delete childrens[i];
                childrens[i] = NULL;
            }
        }
    }
};
class book{
    public:
    trie_node* root;
    vector<string> shabds; //for storing all words of universal book
    book(){
        root = new trie_node(); //empty root
    }
    bool search(string w){
        for (string s:shabds){
            if (s == w){
                return true;
            }
        }
        return false;
    }
    bool is_seperator(char c){
        string sep = ".,-:!\"|\'()?-[]“” ‘’˙;@";
        for (char ch:sep){
            if (ch == c){
                return true;
            }
        }
        return false;
    }
    bool isAlphabet(char c) {
        // Check if the character is an uppercase or lowercase alphabet character
        return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z');
    }
    void insert_unibook(string sentence,long long countt){   //for all book codes
        trie_node* curr = root;
        string shabd = "";   // number of characters in sentence
        int track = 0;
        for (char c:sentence){
            track++;
            if (is_seperator(c)==false){
                int idx = c;
                shabd = shabd+c;
                
                if (curr->childrens[idx]==NULL){
                    curr->childrens[idx] = new trie_node(c);
                }
                curr = curr->childrens[idx];
                if (track == sentence.size()){
                    if (curr->count==0){
                        shabds.push_back(shabd);
                    }
                    shabd = "";
                    curr->count = countt;
                    curr->isword = true;
                    if (sizeof(curr->childrens)==0){
                        curr->eof = true;
                    }
                    curr = root;
                }
            }else{
                if (shabd!=""){
                    if (curr->count==0){
                        shabds.push_back(shabd);
                    }
                    shabd = "";
                    curr->count = countt;
                    curr->isword = true;
                    if (sizeof(curr->childrens)==0){
                        curr->eof = true;
                    }
                    curr = root;
                }
            }
        }
    }

    int word_count(string word){    //in universal book
        trie_node* temp = root;
        if (search(word)==0){
            return 0;
        }
        for (int i=0;i<word.size();i++){
                char c = word[i];
                int idx = c;
            // cout<<1;
            temp = temp->childrens[idx];
        }
        return temp->count;
    }
};
class QNA_tool {

private:

    // You are free to change the implementation of this function
    void query_llm(string filename, Node* root, int k, string API_KEY, string question);
    // filename is the python file which will call ChatGPT API
    // root is the head of the linked list of paragraphs
    // k is the number of paragraphs (or the number of nodes in linked list)
    // API_KEY is the API key for ChatGPT
    // question is the question asked by the user

    // You can add attributes/helper functions here
    vector<vector<int>> give_paragraph_scores(int k);
    vector<paragraph_node> para;
    Dict dict;
    book gcorpora;
    //vector<Dict> books; //specific corpus

public:

    /* Please do not touch the attributes and
    functions within the guard lines placed below  */
    /* ------------------------------------------- */
    
    QNA_tool(); // Constructor
    ~QNA_tool(); // Destructor

    void insert_sentence(int book_code, int page, int paragraph, int sentence_no, string sentence);
    // This function is similar to the functions in dict and search 
    // The corpus will be provided to you via this function
    // It will be called for each sentence in the corpus

    Node* get_top_k_para(string question, int k);
    // This function takes in a question, preprocess it
    // And returns a list of paragraphs which contain the question
    // In each Node, you must set: book_code, page, paragraph (other parameters won't be checked)

    std::string get_paragraph(int book_code, int page, int paragraph);
    // Given the book_code, page number, and the paragraph number, returns the string paragraph.
    // Searches through the corpus.

    void query(string question, string filename);
    // This function takes in a question and a filename.
    // It should write the final answer to the specified filename.

    /* -----------------------------------------*/
    /* Please do not touch the code above this line */

    // You can add attributes/helper functions here
    Node* get_topk(vector<double> scores,maxheap &que,vector<string> words,int k);
};