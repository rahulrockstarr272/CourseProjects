// Do NOT add any other includes
#include <string> 
#include <vector>
#include <iostream>
#include "Node.h"
using namespace std;

class node{
    public:
        int bookno;
        int page;
        int paragrap;
        int sentno;
        string sentence;
        node(int book,int pag,int para,int set, std::string sencent);
        int linersearch(std::string pattern);

};

class SearchEngine {
private:
    vector<node*> sentences;
    
    // You can add attributes/helper functions here
    


public: 
    /* Please do not touch the attributes and 
    functions within the guard lines placed below  */
    /* ------------------------------------------- */
    SearchEngine();

    ~SearchEngine();

    void insert_sentencee(int book_code, int page, int paragraph, int sentence_no, string sentence);

    vector<vector<int>> search(string pattern);
    vector<node*> get_sentences();

    /* -----------------------------------------*/
    //void printer();
};