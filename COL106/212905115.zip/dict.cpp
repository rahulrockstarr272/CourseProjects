// Do NOT add any other includes
#include "dict.h"

Dict::Dict(){
    // Implement your function here 
    root = nullptr;   
}

Dict::~Dict(){
    // Implement your function here  
    delete root;  
}

int Dict::getHeight(AVLNode* node) {
    if (node == nullptr)
        return 0;
    return node->height;
}

int Dict::getBalance(AVLNode* node) {
    if (node == nullptr)
        return 0;
    return getHeight(node->left) - getHeight(node->right);
}

AVLNode* Dict::rightRotate(AVLNode* y) {
    AVLNode* x = y->left;
    AVLNode* T2 = x->right;

    x->right = y;
    y->left = T2;

    y->height = 1 + max(getHeight(y->left), getHeight(y->right));
    x->height = 1 + max(getHeight(x->left), getHeight(x->right));

    return x;
}

AVLNode* Dict::leftRotate(AVLNode* x) {
    AVLNode* y = x->right;
    AVLNode* T2 = y->left;

    y->left = x;
    x->right = T2;

    x->height = 1 + max(getHeight(x->left), getHeight(x->right));
    y->height = 1 + max(getHeight(y->left), getHeight(y->right));

    return y;
}

AVLNode* Dict::insert(AVLNode* node, string key) {
    if (node == nullptr)
        return new AVLNode(key);

    if (key < node->key)
        node->left = insert(node->left, key);
    else if (key > node->key)
        node->right = insert(node->right, key);
    else
        node->count= node->count+1;

    node->height = 1 + max(getHeight(node->left), getHeight(node->right));

    int balance = getBalance(node);

        if (balance > 1 && key < node->left->key) {
            return rightRotate(node);
        }

        if (balance< -1 && key > node->right->key) {
            return leftRotate(node);
        }

        if (balance > 1 && key > node->left->key) {
            node->left = leftRotate(node->left);
            return rightRotate(node);
        }

        if (balance < -1 && key < node->right->key) {
            node->right = rightRotate(node->right);
            return leftRotate(node);
        }

    return node;
}

void Dict::insert_sentenc(int book_code, int page, int paragraph, int sentence_no, string sentence) {
    string word = "";
    for (char c : sentence) {
        if (c == ' ' || c == '.' || c == ',' || c == '-' || c == ':' || c == '!' || c == '\"' || c == '\'' || c == '(' || c == ')' || c == '?' || c == '—' || c == '[' || c == ']' || c == '“' || c == '”' || c == '‘' || c == '’' || c == '˙' || c == ';' || c == '@') {
            if (!word.empty()) {
                root = insert(root, word);
                word = "";
            }
        } else {
            word += tolower(c);
        }
    }
    if (!word.empty()) {
        root = insert(root, word);
    }
}



// void Dict::insert_sentence(int book_code, int page, int paragraph, int sentence_no, string sentence) {
//     string word = "";
//     for (char c : sentence) {
//         if (isalnum(c) || c == '\'') {
//             // Append the character to the word while it's alphanumeric or an apostrophe.
//             word += tolower(c);
//         } else if (!word.empty()) {
//             // When a non-alphanumeric character is encountered, insert the word into the AVL tree.
//             root = insert(root, word);
//             word = "";  // Reset the word.
//         }
//     }
//     if (!word.empty()) {
//         // Insert the last word if it's not empty.
//         root = insert(root, word);
//     }
// }


long long Dict::get_word_count(string word){

    for (char& c : word) {
        c = tolower(c);
    }

    AVLNode* current = root;
    while (current) {
        if (word < current->key)
            current = current->left;
        else if (word > current->key)
            current = current->right;
        else
            return current->count;
    }

    return 0;
}

void Dict::dump_dictionary(string filename){
    ofstream outputFile(filename);
        struct StackNode {
            AVLNode* node;
            StackNode* next;
        };
        
        StackNode* stack = nullptr;
        AVLNode* current = root;

        while (current != nullptr || stack != nullptr) {
            while (current != nullptr) {
                StackNode* newNode = new StackNode;
                newNode->node = current;
                newNode->next = stack;
                stack = newNode;
                current = current->left;
            }

            current = stack->node;
            stack = stack->next;

            outputFile << current->key << ", " << current->count << endl;

            current = current->right;
        }

        while (stack != nullptr) {
            StackNode* temp = stack;
            stack = stack->next;
            delete temp;
        }

        outputFile.close();
}