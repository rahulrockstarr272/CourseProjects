// Do NOT add any other includes
#include <string> 
#include <vector>
#include <iostream>
#include <fstream>
using namespace std;

class AVLNode {
public:
    string key;
    long long count;
    AVLNode* left;
    AVLNode* right;
    int height;

    AVLNode(string k) {
        key = k;
        count = 1;
        left = right = nullptr;
        height = 1;
    }
};

class Dict {
private:
    // You can add attributes/helper functions here
    AVLNode* root;

    int getHeight(AVLNode* node);
    int getBalance(AVLNode* node);
    AVLNode* rightRotate(AVLNode* node);
    AVLNode* leftRotate(AVLNode* node);
    AVLNode* insert(AVLNode* node, string key);
    AVLNode* minValueNode(AVLNode* node);
    AVLNode* deleteNode(AVLNode* root, string key);

public: 
    /* Please do not touch the attributes and 
    functions within the guard lines placed below  */
    /* ------------------------------------------- */
    Dict();

    ~Dict();

    void insert_sentenc(int book_code, int page, int paragraph, int sentence_no, string sentence);

    long long get_word_count(string word);

    void dump_dictionary(string filename);

    /* -----------------------------------------*/
};