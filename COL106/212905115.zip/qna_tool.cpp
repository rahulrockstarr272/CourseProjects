#include <assert.h>
#include <sstream>
#include "qna_tool.h"
//#include<queue>
//#include<algorithm>  //n
#define FILENAME "mahatma-gandhi-collected-works-volume-1.txt"
using namespace std;

QNA_tool::QNA_tool(){
    //dict.resize(99);
    ifstream file("unigram_freq.csv");
    string line, word; 
    string count;
    while (std::getline(file,line)) {
        //cout<<1;
        // used for breaking words 
        stringstream ss(line);
        // Read word and count from the CSV line
        getline(ss,word,',');
        getline(ss,count,',');
        if (count!="count"){
            gcorpora.insert_unibook(word,std::stoll(count));
            //cout<<word<<":"<<gcorpora.word_count(word)<<endl;
        }
        //cout<<word<<":"<<count;

    }
    file.close();
}
QNA_tool::~QNA_tool(){
    // Implement your function here
}
void QNA_tool::insert_sentence(int book_code, int page, int paragraph, int sentence_no, string sentence){
    paragraph_node n;
    n.bookcode = book_code;
    n.page = page;
    n.paragraph = paragraph;
    n.sentence_no = sentence_no;
    n.sentence = sentence;
    para.push_back(n);
    // dict[book_code].insert_sentenc(book_code,page,paragraph,sentence_no,sentence);  
    dict.insert_sentenc(book_code,page,paragraph,sentence_no,sentence);
    return;
}
//helper functions start::::
bool is_seperator(char c){
    string sep = ".,-:!\"|\'()?-[]“” ‘’˙;@";
    for (char ch:sep){
        if (ch == c){
            return true;
        }
    }
    return false;
}
bool search_(vector<string> word,string s){
    for (const string& w : word){
        if (w == s){
            return true;
        }
    }
    return false;
}
bool is_seperator_(char c){
    string sep = ".,-:!\"|\'()?-[]“” ‘’˙;@";
    for (char ch:sep){
        if (ch == c){
            return true;
        }
    }
    return false;
}
vector<string> get_words(string question){
    vector<string> ans;
    string s = "";
    for(char p : question){
        if(is_seperator(p)){
            if(s.size() > 0){
                bool inAns = false;
                for(auto p : ans){
                    if(p == s){
                        inAns = true; break;
                    }
                }
                if(!inAns) ans.push_back(s); 
                s = "";
            }
            continue;
        }
        s += p;
    } 
    if(s.size() > 0){
        bool inAns = false;
        for(auto p : ans){
            if(p == s){
                inAns = true; break;
            }
        }
        if(!inAns) ans.push_back(s); 
    }
    return ans;
}
vector<string> get_words_multiple(string question){
  vector<string> words;
  string shabd = "";
  int track = 0;
  for (char c:question){
    track++;
    if (!is_seperator_(c)){
      shabd += c;
      if (track == question.size() && shabd.size() != 0){
        words.push_back(shabd);
      }
    }else{
      if (shabd.size() != 0){
        words.push_back(shabd);
        shabd = "";
      }
      shabd = "";
    }
  }
  return words;
}
int freq(string w,string para){
  string shabd = "";
  int track = 0;
  int count = 0;
  for (char c:para){
    track++;
    if (!is_seperator(c)){
      shabd += c;
      if (track == para.size() && shabd.size() != 0){
        if (shabd == w){
          count++;

        }
      }
    }else{
      if (shabd.size() != 0){
        if (shabd == w){
          count++;
        }
        //shabd = "";
      }
      shabd = "";
    }
  }
  return count;
}
// helper functions end:::
Node* QNA_tool::get_top_k_para(string question, int k) {
    // Implement your function here
    //need to update pattern search a bit
    string sep = ".,-:!\"|\'()?-[]“” ‘’˙;@";
    vector<string> words_of_question = get_words(question);
    vector<double> scores;
    for (string w:words_of_question){  //freq(w,question)*
        double score = freq(w,question)*(dict.get_word_count(w)+1)/(double)(gcorpora.word_count(w)+1);
        scores.push_back(score);
        //cout<<score<<endl;
    }
    maxheap que;
    Node* ans = get_topk(scores,que,words_of_question,k); //return link list
    //cout<<1;
    return ans;
}
Node* QNA_tool::get_topk(vector<double> scores,maxheap &que,vector<string> words_of_question,int k){
    string sep = ".,-:!\"|\'()?-[]“” ‘’˙;@";
    for (paragraph_node n:para){
        vector<string> words_of_para = get_words(n.sentence);
        int idx = -1;
        double sc = 0;
        for (string w:words_of_question){
            idx++;
            if (search_(words_of_para,w)){
                sc += scores[idx]*((double)freq(w,n.sentence));
            }
        }
        n.scorep = (double)sc;
        que.insert(n);
        // if (n.scorep != 0){
        //     cout<<n.scorep;
        // }
        
    }
    Node* head;
    Node* tail;
    for (int i=0;i<k;i++){
        paragraph_node n = que.top();
        que.pop();
        //cout<<n.scorep<<":";
        if (i == 0){
            head = new Node(n.bookcode,n.page,n.paragraph,-1,-1);
            tail = head;
        }else{
            Node* newnode = new Node(n.bookcode,n.page,n.paragraph,-1,-1);
            tail->right = newnode;
            newnode->left = tail;
            tail = newnode;
        }
    }
    return head;
}

void QNA_tool::query(string question, string filename){
    // Implement your function here  
    ofstream file(filename);
    file.open(filename);
    Node* topk = get_top_k_para(question,8);
    return;
}


std::string QNA_tool::get_paragraph(int book_code, int page, int paragraph){

    cout << "Book_code: " << book_code << " Page: " << page << " Paragraph: " << paragraph << endl;
    
    std::string filename = "mahatma-gandhi-collected-works-volume-";
    filename += to_string(book_code);
    filename += ".txt";

    std::ifstream inputFile(filename);

    std::string tuple;
    std::string sentence;

    if (!inputFile.is_open()) {
        std::cerr << "Error: Unable to open the input file " << filename << "." << std::endl;
        exit(1);
    }

    std::string res = "";

    while (std::getline(inputFile, tuple, ')') && std::getline(inputFile, sentence)) {
        // Get a line in the sentence
        tuple += ')';

        int metadata[5];
        std::istringstream iss(tuple);

        // Temporary variables for parsing
        std::string token;

        // Ignore the first character (the opening parenthesis)
        iss.ignore(1);

        // Parse and convert the elements to integers
        int idx = 0;
        while (std::getline(iss, token, ',')) {
            // Trim leading and trailing white spaces
            size_t start = token.find_first_not_of(" ");
            size_t end = token.find_last_not_of(" ");
            if (start != std::string::npos && end != std::string::npos) {
                token = token.substr(start, end - start + 1);
            }
            
            // Check if the element is a number or a string
            if (token[0] == '\'') {
                // Remove the single quotes and convert to integer
                int num = std::stoi(token.substr(1, token.length() - 2));
                metadata[idx] = num;
            } else {
                // Convert the element to integer
                int num = std::stoi(token);
                metadata[idx] = num;
            }
            idx++;
        }

        if(
            (metadata[0] == book_code) &&
            (metadata[1] == page) &&
            (metadata[2] == paragraph)
        ){
            res += sentence;
        }
    }

    inputFile.close();
    return res;
}

void QNA_tool::query_llm(string filename, Node* root, int k, string API_KEY, string question){

    // first write the k paragraphs into different files

    Node* traverse = root;
    int num_paragraph = 0;

    while(num_paragraph < k){
        assert(traverse != nullptr);
        string p_file = "paragraph_";
        p_file += to_string(num_paragraph);
        p_file += ".txt";
        // delete the file if it exists
        remove(p_file.c_str());
        ofstream outfile(p_file);
        string paragraph = get_paragraph(traverse->book_code, traverse->page, traverse->paragraph);
        assert(paragraph != "$I$N$V$A$L$I$D$");
        outfile << paragraph;
        outfile.close();
        traverse = traverse->right;
        num_paragraph++;
    }

    // write the query to query.txt
    ofstream outfile("query.txt");
    outfile << "These are the excerpts from Mahatma Gandhi's books.\nOn the basis of this, ";
    outfile << question;
    // You can add anything here - show all your creativity and skills of using ChatGPT
    outfile.close();
 
    // you do not need to necessarily provide k paragraphs - can configure yourself

    // python3 <filename> API_KEY num_paragraphs query.txt
    string command = "python3 ";
    command += filename;
    command += " ";
    command += API_KEY;
    command += " ";
    command += to_string(k);
    command += " ";
    command += "query.txt";

    system(command.c_str());
    return;
}