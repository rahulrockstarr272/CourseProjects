/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "ulimitedint.h"
//#include<iostream>    // hata dio
std::string repeatString(const std::string& str, int times) {
    std::string result;
    for (int i = 0; i < times; ++i) {
        result += str;
    }
    return result;
}




UnlimitedInt::UnlimitedInt(){
    size = 0;
    capacity = 1024;
    unlimited_int = new int[capacity];
    for (int i=0;i<capacity;i++){
        unlimited_int[i]=0;
    }
    sign = 1;
}
UnlimitedInt::UnlimitedInt(string s) {
    size = 0;
    capacity = 1024;
    unlimited_int = new int[capacity];
    sign = 1; 

    if (s[0] == '-') {
        s = s.substr(1); 
        sign = -1; 
    }

    for (int i = s.size() - 1; i >= 0; i--) {
        char c = s[i];
        if (c >= '0' && c <= '9') {
            int input = c - '0';
            if (capacity == size) {
                int* temp;
                temp = new int[capacity * 2];
                for (int j = 0; j < capacity; j++) {
                    temp[j] = unlimited_int[j];
                }
                delete[] unlimited_int;
                unlimited_int = temp;
                unlimited_int[size] = input;
                size++;
                capacity = capacity * 2;
            } else {
                unlimited_int[size] = input;
                size++;
            }
        }
    }
}

UnlimitedInt::UnlimitedInt(int i) {
    string s = std::to_string(i);
    size = 0;
    capacity = 1024;
    unlimited_int = new int[capacity];
    sign = 1; // Set the default sign to positive

    if (s[0] == '-') {
        s = s.substr(1); // Remove the minus sign
        sign = -1; // Set the sign to negative
    }

    for (int j = s.size() - 1; j >= 0; j--) {
        char c = s[j];
        if (c >= '0' && c <= '9') {
            int input = c - '0';
            if (capacity == size) {
                int* temp;
                temp = new int[capacity * 2];
                for (int k = 0; k < capacity; k++) {
                    temp[k] = unlimited_int[k];
                }
                delete[] unlimited_int;
                unlimited_int = temp;
                unlimited_int[size] = input;
                size++;
                capacity = capacity * 2;
            } else {
                unlimited_int[size] = input;
                size++;
            }
        }
    }
}
UnlimitedInt::~UnlimitedInt(){
    capacity = 0;
    size = 0;
    sign = 1;
    delete[] unlimited_int;
}
int UnlimitedInt::get_size(){
    return size;
}
int* UnlimitedInt::get_array(){
    return unlimited_int;
}
int UnlimitedInt::get_sign(){
    return sign;
}
int UnlimitedInt::get_capacity(){
    return capacity;
}
                                         //update wrt sign
UnlimitedInt* UnlimitedInt::add(UnlimitedInt* i1,UnlimitedInt* i2){
    UnlimitedInt* result;
    //string s1="";
    //ring s2="";
    //cout<<"h1";
    int sign_ = 1;
    int s1 = i1->get_sign();
    int s2 = i2->get_sign();
    int size1 = i1->get_size();
    int size2 = i2->get_size();
    int minn = min(size1,size2);
    int maxx = max(size1,size2);
    int* ar1= new int[i1->get_capacity()];
    int* ar2 = new int[i2->get_capacity()];
    for (int i = 0;i<i1->get_capacity();i++){
        ar1[i] = i1->get_array()[i];
    }
    for (int i = 0;i<i2->get_capacity();i++){
        ar2[i] = i2->get_array()[i];
    }
    
    int capacity_ = i1->get_capacity();
    int* arr = new int[capacity_];
    for (int i=0;i<capacity_;i++){
        arr[i] = 0;
    }
    int siz = 0;
    if (s1*s2 == 1){
        //cout<<"h1";
        sign_ = s1;
        for (int i=0;i<minn;i++){
            int val = ar1[i]+ar2[i]+arr[i];          //taken care of carry
            if (val>=10){
                arr[i] = val%10;
                arr[i+1] += 1;
                if (size1==size2 && i==minn-1){
                    siz++;
                }
                siz++;
            }else{
                arr[i] = val;
                siz++;
            }
        }          //rest add
        if (size1>size2){
            //cout<<"h1";
            for (int i=size2;i<size1;i++){
                int val = ar1[i]+arr[i];
                if (val>=10){
                    arr[i] = val%10;
                    arr[i+1] += 1;
                    if (i==size1-1){
                        siz++;
                    }
                    siz++;
                }else{
                    arr[i] = val;
                    siz++;
                }
            }
        }
        if (size2>size1){
            //cout<<"h1";
            for (int i=size1;i<size2;i++){
                int val = ar2[i]+arr[i];
                if (val>=10){
                    arr[i] = val%10;
                    arr[i+1] += 1;
                    if (i==size1-1){
                        siz++;
                    }
                    siz++;
                }else{
                    arr[i] = val;
                    siz++;
                }
            }
        }
    }else{
        if (s1 == -1){
            UnlimitedInt* minus = new UnlimitedInt("-1");
            UnlimitedInt* dummy = mul(i1,minus);
            arr = i1->sub(i2,dummy)->get_array();
            siz = i1->sub(i2,dummy)->get_size();
            sign_ = i1->sub(i2,dummy)->get_sign();
        }else{
            UnlimitedInt* minus = new UnlimitedInt("-1");
            UnlimitedInt* dummy = mul(i2,minus);
            arr = i1->sub(i1,dummy)->get_array();
            siz = i1->sub(i1,dummy)->get_size();
            sign_ = i1->sub(i1,dummy)->get_sign();
        }
    }
    //cout<<"h1";
    string s = "";
    for (int i = siz-1;i>-1;i--){
        s += std::to_string(arr[i]);
    }
    if (sign_ == -1){
        s = "-" + s;
    }
    result = new UnlimitedInt(s);
    delete[] arr;
    delete[] ar1;
    delete[] ar2;
    return result;
}
//helper function 1
UnlimitedInt* UnlimitedInt::sub(UnlimitedInt* i1, UnlimitedInt* i2) {
    UnlimitedInt* result;
    int sign_ = 1;
    int s1 = i1->get_sign();
    int s2 = i2->get_sign();
    int size1 = i1->get_size();
    int size2 = i2->get_size();
    int minn = min(size1,size2);
    int maxx = max(size1,size2);
    int* ar1_ = i1->get_array();
    int* ar1 = new int[i1->get_capacity()];
    for (int i=0;i<size1;i++){
        ar1[i] = ar1_[i];
    }
    int* ar2 = new int[i2->get_capacity()];
    int* ar2_ = i2->get_array();
    for (int i = 0;i<size2;i++){
        ar2[i] = ar2_[i];
    }
    int* arr = new int[maxx];
    for (int i=0;i<maxx;i++){
        arr[i] = 0;
    }
    //int* carry;
    int siz = 0;
    if (size1>size2){
        if (s1 == -1 && s2 == 1){
            sign_ = -1;
            string ss = i2->to_string();
            ss= "-"+ss;
            UnlimitedInt* neww = new UnlimitedInt(ss);
            arr = i1->add(i1,neww)->get_array();
            siz = i1->add(i1,neww)->get_size();
        }
        else if (s1 == 1 && s2 == -1){
            sign_ = 1;
            string ss = i2->to_string();
            ss= ss.substr(1);
            UnlimitedInt* neww = new UnlimitedInt(ss);
            arr = i1->add(i1,neww)->get_array();
            siz = i1->add(i1,neww)->get_size();
        }
        else{
            sign_ = s1;
            for (int i=0;i<size2;i++){
                int val = ar1[i] - ar2[i];
                if (val>=0){
                    arr[i] = val;
                    siz++;
                }else{
                    bool ans = true;
                    int k =i+1;
                    while(ar1[k]==0){
                        //
                        //cout<<k<<endl;
                        k++;

                    }
                    while (k!=i){
                        ar1[k] = ar1[k]-1;
                        //cout<<ar2[k]<<endl;
                        string s = std::to_string(ar1[k-1]);
                        ar1[k-1] = stoi("1"+s);
                        k--;
                    }
                    val = ar1[i] - ar2[i];
                    arr[i] = val;
                    siz++;
                }
            }
            //rest values
            for (int i = size2;i<size1;i++){
                arr[i] = ar1[i];
                //cout<<ar2[i]<<endl;
                siz++;
            }
            }
        
    }
    else if (size2>size1){
        if (s2 == -1 && s1 == 1){
            sign_ = -1;
            string ss = i1->to_string();
            ss= "-"+ss;
            UnlimitedInt* neww = new UnlimitedInt(ss);
            arr = i2->add(i2,neww)->get_array();
            siz = i2->add(i2,neww)->get_size();
        }
        else if (s2 == 1 && s1 == -1){
            sign_ = 1;
            string ss = i1->to_string();
            ss= ss.substr(1);
            UnlimitedInt* neww = new UnlimitedInt(ss);
            arr = i1->add(i2,neww)->get_array();
            siz = i1->add(i2,neww)->get_size();
        }
        else{
            sign_ = s2*-1;
            for (int i=0;i<size1;i++){
                int val = ar2[i] - ar1[i];
                if (val>=0){
                    arr[i] = val;
                    siz++;
                }else{
                    //bool ans = true;
                    int k =i+1;
                    while(ar2[k]==0){
                        //
                        //cout<<k<<endl;
                        k++;

                    }
                    while (k!=i){
                        ar2[k] = ar2[k]-1;
                        //cout<<ar2[k]<<endl;
                        string s = std::to_string(ar2[k-1]);
                        ar2[k-1] = stoi("1"+s);
                        k--;
                    }
                    val = ar2[i] - ar1[i];
                    arr[i] = val;
                    siz++;
                }
            }
            //rest values
            for (int i = size1;i<size2;i++){
                arr[i] = ar2[i];
                //cout<<ar2[i]<<endl;
                siz++;
            }
            }
        }
    else{ // equla size
        if (s1 == 1 && s2 == -1){
            sign_ = 1;
            string S = i2->to_string();
            S = S.substr(1);
            UnlimitedInt* neww = new UnlimitedInt(S);
            arr = i2->add(i1,neww)->get_array();
            siz = i2->add(i1,neww)->get_size();                     
        }
        else if (s1 == -1 && s2 == 1){
            sign_ = -1;
            string S = i2->to_string();
            S = "-"+S;
            UnlimitedInt* neww = new UnlimitedInt(S);
            arr = i2->add(i1,neww)->get_array();
            siz = i2->add(i1,neww)->get_size(); 
        }else{
            int val;
            for (int i = size1-1;i>-1;i--){
                //cout<<ar1[i]<<";"<<ar2[i]<<endl;
                if (ar1[i]!=ar2[i]){
                    val = ar1[i] - ar2[i];
                    //cout<<val;
                    break;
                }
            }
            if (val>0){
                sign_ = s1;
                for (int i=0;i<size2;i++){
                    int val = ar1[i] - ar2[i];
                    if (val>=0){
                        arr[i] = val;
                        siz++;
                    }else{
                        bool ans = true;
                        int k =i+1;
                        while(ar1[k]==0){
                            //
                            //cout<<k<<endl;
                            k++;

                        }
                        while (k!=i){
                            ar1[k] = ar1[k]-1;
                            //cout<<ar2[k]<<endl;
                            string s = std::to_string(ar1[k-1]);
                            ar1[k-1] = stoi("1"+s);
                            k--;
                        }
                        val = ar1[i] - ar2[i];
                        arr[i] = val;
                        siz++;
                    }
                }
            }else{
                sign_ = s1*-1;
                for (int i=0;i<size1;i++){
                    int val = ar2[i] - ar1[i];
                    if (val>=0){
                        arr[i] = val;
                        siz++;
                    }else{
                        //bool ans = true;
                        int k =i+1;
                        while(ar2[k]==0){
                            //
                            //cout<<k<<endl;
                            k++;

                        }
                        while (k!=i){
                            ar2[k] = ar2[k]-1;
                            //cout<<ar2[k]<<endl;
                            string s = std::to_string(ar2[k-1]);
                            ar2[k-1] = stoi("1"+s);
                            k--;
                        }
                        val = ar2[i] - ar1[i];
                        arr[i] = val;
                        siz++;
                    }
                }
            }
        }
    }
    string s = "";
    //bool ans = true;
    int j =siz-1;
    if (arr[j]==0){
        for (int k = j;k>-1;k--){
            if (arr[k]!=0){
                j = k;
                break;
            }
            else if (k==0 && arr[k]==0){
                j = k;
                break;
            }
        }
    }
    for (int i=j;i>-1;i--){
        s+=std::to_string(arr[i]);
        
    }
    if (sign_ == -1){
        s = "-"+s;
    }
    result = new UnlimitedInt(s);
    return result;
}





UnlimitedInt* UnlimitedInt::mul(UnlimitedInt* i1,UnlimitedInt* i2){
    if (i1->to_string()=="0" || i2->to_string()=="0"){
        UnlimitedInt* multiply = new UnlimitedInt("0");
        return multiply;
    }
    // 1 * 2
    else{
        int sign_ = 1;
        int s1 = i1->get_sign();
        int s2 = i2->get_sign();
        int size1 = i1->get_size();
        int size2 = i2->get_size();
        int minn = min(size1,size2);
        int maxx = max(size1,size2);
        int* ar1= new int[i1->get_capacity()];
        int* ar2 = new int[i2->get_capacity()];
        int* arr = new int[i2->get_capacity()];
        string* store = new string[i1->get_capacity()];
        for (int i = 0;i<i1->get_capacity();i++){
            ar1[i] = i1->get_array()[i];
        }
        for (int i = 0;i<i2->get_capacity();i++){
            ar2[i] = i2->get_array()[i];
        }
        for (int i = 0;i<i2->get_capacity();i++){
            arr[i] = 0;
            store[i] = "";
        }
        int* result = new int[i2->get_capacity()];
        for (int i = 0;i<size1;i++){
            string s = "";
            for (int j = 0;j<size2;j++){
                int num = (ar1[i])*(ar2[j])+arr[j];
                if (num>=10){
                    if (j == size2-1){
                        s = std::to_string(num) + s;
                    }else{
                    int rem = num%10;
                    int carry = num/10;
                    arr[j+1] = carry;
                    s = std::to_string(rem) + s;
                    }
                }
                else{
                    s = std::to_string(num) + s;
                }
            }
            for (int k = 0;k<i;k++){
                s = s + "0";
            }
            store[i] = s ;
            for (int i=0;i<size2;i++){
                arr[i] = 0;
            }
        }
        UnlimitedInt* addition = new UnlimitedInt(store[0]);
        for (int i = 1;i<size1;i++){
            UnlimitedInt* dummy = new UnlimitedInt(store[i]);
            addition = add(addition,dummy);
        }
        if (s1*s2 == 1){
            delete[] ar1;
            delete[] ar2;
            delete[] arr;
            delete[] store;
            return addition;
        }else{
            string ss = "-"+addition->to_string();
            UnlimitedInt* multiply = new UnlimitedInt(ss);
            delete[] ar1;
            delete[] ar2;
            delete[] arr;
            delete[] store;
            return multiply;
        }
    }
}

bool strictlySmaller(UnlimitedInt* n1,UnlimitedInt* n2){
    return n1->sub(n1,n2)->get_sign()==1 || n1->sub(n1,n2)->to_string()=="0";
}
bool isSmaller(UnlimitedInt* n1,UnlimitedInt* n2){
    return n1->sub(n1,n2)->get_sign()==1 && n1->sub(n1,n2)->to_string()!="0";
}
UnlimitedInt* powerOfTwo(UnlimitedInt* c){
    if (c->to_string()=="0"){
        return new UnlimitedInt("1");
    }
    if (c->to_string()=="1"){
        return new UnlimitedInt("2");
    }
    UnlimitedInt* two = new UnlimitedInt("2");
    UnlimitedInt* twod = new UnlimitedInt("2");
    UnlimitedInt* one = new UnlimitedInt("1");
    UnlimitedInt* oned = new UnlimitedInt("1");
    while (true){
        two = c->mul(twod,two);
        one = one->add(one,oned);
        if (one->to_string()==c->to_string()){
            return two;
        }

    }
}
UnlimitedInt* UnlimitedInt::div(UnlimitedInt* i1, UnlimitedInt* i2){
        UnlimitedInt* zeroInt= new UnlimitedInt("0");
        int s1 = i1->get_sign();
        int s2 = i2->get_sign();
        if(i1->to_string()=="0"){
            return zeroInt;
        }
        else if(i2->to_string()=="1"){
            return i1;
        }
        UnlimitedInt* ans=new UnlimitedInt("0");
        UnlimitedInt* oneInt=new UnlimitedInt("1");
        UnlimitedInt* minusOne=new UnlimitedInt("-1");
        UnlimitedInt* num=new UnlimitedInt(i1->to_string()); // copy of i1
        UnlimitedInt* den=new UnlimitedInt(i2->to_string()); // copy of i2
        if (num->get_sign()==-1){
            num=num->mul(num,minusOne);
        }
        if (den->get_sign()==-1){
            den=den->mul(den,minusOne);
        }
        UnlimitedInt* two=new UnlimitedInt("2");
        bool flag=true;
        while(flag==true){
            if(num->to_string()=="0" or !strictlySmaller(num,den)==true) break;
            UnlimitedInt* count=new UnlimitedInt("0");
            flag=false;
            while(true){
                UnlimitedInt* result=i1->mul(den,two);
                if(!isSmaller(result,num)==false){
                    break;
                }
                den=result;
                count=i1->add(count,oneInt);
                flag=true;
            }
            num=i1->sub(num,den);
            delete den;
            den=new UnlimitedInt(i2->to_string());
            //den->get_array()[0]=1;
            if (den->get_sign()==-1){
                den = den->mul(den,minusOne);
            }
            //den->sign=1;
            ans=i1->add(ans,powerOfTwo(count));
        }
        if(i1->get_sign() != i2->get_sign()){
            ans=i1->mul(ans,minusOne);
        }
        delete num;
        delete den;
        if (s1*s2 == -1){
            ans = sub(ans,new UnlimitedInt("1"));
        }
        return ans;
    }



UnlimitedInt* UnlimitedInt::mod(UnlimitedInt* i1,UnlimitedInt* i2){
    if (i2->to_string() == "1"){
        return new UnlimitedInt("0");
    }
    //UnlimitedInt* result;
    UnlimitedInt* floor = div(i1,i2);
    

    UnlimitedInt* q = mul(i2,floor);
    return sub(i1,q);
}
string UnlimitedInt::to_string(){
    string s="";
    for (int i = size-1;i>=0;i--){
        s = s + std::to_string(unlimited_int[i]);
    }
    if (sign == -1){
        s = "-"+s;
    }
    return s;
}




















