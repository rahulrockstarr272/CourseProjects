/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "ulimitedrational.h"
#include "ulimitedint.h"
//#include<iostream>
//using namespace std;
UnlimitedRational::UnlimitedRational(){
}
UnlimitedInt* gcd(UnlimitedInt* a, UnlimitedInt* b){
    if (a->to_string()=="0" || b->to_string()=="0"){
        return new UnlimitedInt("1");
    }
    if (a->get_sign()==-1){
        a = UnlimitedInt::mul(a,new UnlimitedInt("-1"));
    }
    if (b->get_sign()==-1){
        b = UnlimitedInt::mul(b,new UnlimitedInt("-1"));
    }
    while (b->to_string()!="0"){
        //cout << "a: " << a->to_string() << ", b: " << b->to_string() << endl;
        UnlimitedInt* a_deepcopy = new UnlimitedInt(a->to_string());
        //delete a;
        a = b;
        b = UnlimitedInt::mod(a_deepcopy, b);
        
    }
    //cout<<a->to_string();
    return new UnlimitedInt(a->to_string());
}

UnlimitedRational::UnlimitedRational(UnlimitedInt* num, UnlimitedInt* den){
    UnlimitedInt* gcdd = gcd(num,den);
   p = UnlimitedInt::div(num,gcdd);
    q = UnlimitedInt::div(den,gcdd);
    //p = num;
    //q = den;
}
UnlimitedRational::~UnlimitedRational(){
    delete p;
    delete q;
}
UnlimitedInt* UnlimitedRational::get_p(){
    return p;
}
UnlimitedInt* UnlimitedRational::get_q(){
    return q;
}
string UnlimitedRational:: get_p_str(){
    return p->to_string();
}
string UnlimitedRational:: get_q_str(){
    return q->to_string();
}
string UnlimitedRational::get_frac_str(){
    string p_ = p->to_string();
    string q_ = q->to_string();
    return p_ + "/" + q_;
}
UnlimitedRational* UnlimitedRational::add(UnlimitedRational* i1, UnlimitedRational* i2){
    //UnlimitedRational* r;
    string p1 = i1->get_p()->UnlimitedInt::to_string();
    string q1 = i1->get_q()->UnlimitedInt::to_string();
    string p2 = i2->get_p()->UnlimitedInt::to_string();
    string q2 = i2->get_q()->UnlimitedInt::to_string();
    
    UnlimitedInt* x = new UnlimitedInt(p1);

    UnlimitedInt* y = new UnlimitedInt(q1);

    UnlimitedInt* t = new UnlimitedInt(p2);
    UnlimitedInt* s = new UnlimitedInt(q2);

    UnlimitedInt* num = x->add(x->mul(x,s),x->mul(t,y));
    UnlimitedInt* den = x->mul(y,s);
    UnlimitedInt* gcdd = gcd(num,den);
    num= UnlimitedInt::div(num,gcdd);
    den = UnlimitedInt::div(den,gcdd);
    UnlimitedRational* result = new UnlimitedRational(num,den);
    return result;
}
UnlimitedRational* UnlimitedRational::sub(UnlimitedRational* i1, UnlimitedRational* i2){
    UnlimitedRational* r;
    UnlimitedInt* x = new UnlimitedInt(i1->get_p()->to_string());
    UnlimitedInt* y = new UnlimitedInt(i1->get_q()->to_string());
    UnlimitedInt* t = new UnlimitedInt(i2->get_p()->to_string());
    UnlimitedInt* s = new UnlimitedInt(i2->get_q()->to_string());
    UnlimitedInt* num = x->sub(x->mul(x,s),x->mul(t,y));
    UnlimitedInt* den = x->mul(y,s);
        UnlimitedInt* gcdd = gcd(num,den);
    num= UnlimitedInt::div(num,gcdd);
    den = UnlimitedInt::div(den,gcdd);
    UnlimitedRational* result = new UnlimitedRational(num,den);
    return result;
}
UnlimitedRational* UnlimitedRational::mul(UnlimitedRational* i1, UnlimitedRational* i2){
    //UnlimitedRational* r;
    UnlimitedInt* x = new UnlimitedInt(i1->get_p()->to_string());
    UnlimitedInt* y = new UnlimitedInt(i1->get_q()->to_string());
    UnlimitedInt* t = new UnlimitedInt(i2->get_p()->to_string());
    UnlimitedInt* s = new UnlimitedInt(i2->get_q()->to_string());
    UnlimitedInt* num = x->mul(x,t);
    UnlimitedInt* den = x->mul(y,s);
    UnlimitedInt* gcdd = gcd(num,den);
    num= UnlimitedInt::div(num,gcdd);
    den = UnlimitedInt::div(den,gcdd);
    UnlimitedRational* result = new UnlimitedRational(num,den);
    return result;
}
UnlimitedRational* UnlimitedRational::div(UnlimitedRational* i1, UnlimitedRational* i2){
    //UnlimitedRational* r;
    UnlimitedInt* x = new UnlimitedInt(i1->get_p()->to_string());
    UnlimitedInt* y = new UnlimitedInt(i1->get_q()->to_string());
    UnlimitedInt* t = new UnlimitedInt(i2->get_p()->to_string());
    UnlimitedInt* s = new UnlimitedInt(i2->get_q()->to_string());
    UnlimitedInt* num = x->mul(x,s);
    UnlimitedInt* den = x->mul(y,t);
    UnlimitedInt* gcdd = gcd(num,den);
    num= UnlimitedInt::div(num,gcdd);
    den = UnlimitedInt::div(den,gcdd);
    UnlimitedRational* result = new UnlimitedRational(num,den);
    return result;
}
