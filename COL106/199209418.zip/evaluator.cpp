/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "evaluator.h"
//#include<iostream>
//#include<queue>
//using namespace std;
class Stack {
public:
    std::vector<ExprTreeNode*> stack;
    ~Stack(){           //n after +2
    }
  

    void push(ExprTreeNode* node) {
        stack.push_back(node);
    }

    ExprTreeNode* pop() {
        if (!stack.empty()) {
            ExprTreeNode* top = stack.back();
            stack.pop_back();
            return top;
        }
        return nullptr; 
    }
};
Evaluator::Evaluator(){
    symtable = new SymbolTable();
}
Evaluator::~Evaluator(){
    delete symtable;
    while (expr_trees.size()!=0){        //n to delete exp tree
        expr_trees.pop_back();
    }
}
bool isInteger(const std::string& str) {
    for (char c : str) {
        if (!std::isdigit(c)) {
            return false;
        }
    }
    return true;
}
bool isoperator(string s){
    return s=="/" || s=="+" || s=="-" || s=="*";
}
UnlimitedRational* evalhelper(ExprTreeNode* rootnode){
        if(rootnode==nullptr) return nullptr;
        else if(rootnode->type=="VAL"){
           // cout<<1<<endl;
            return rootnode->val;
        }
        else if(rootnode->type=="VAR"){
           // cout<<2<<endl;
            UnlimitedRational* result=rootnode->evaluated_value;
            return  result;
        }
        else { // node is an operator;
            string op=rootnode->type;
            UnlimitedRational* leftresult=evalhelper(rootnode->left);
            UnlimitedRational* rightresult=evalhelper(rootnode->right);
            UnlimitedRational* result;
            if(op=="ADD"){
                //cout<<"add"<<endl;
                //cout<<leftresult->get_frac_str();
                result = UnlimitedRational::add(leftresult,rightresult);
            }
            else if(op=="SUB"){
                result=UnlimitedRational::sub(leftresult,rightresult);
            }
            else if(op=="MUL"){
                //cout<<"mul"<<endl;
                result=UnlimitedRational::mul(leftresult,rightresult);
            }
            else if(op=="DIV"){
                result=UnlimitedRational::div(leftresult,rightresult);
            }
            rootnode->evaluated_value=result;
            // cout<<rootnode->evaluated_value->get_frac_str()<<endl;
            return result;
        }
        return nullptr;

}
void buildParseTree(const std::vector<std::string>& tokens,ExprTreeNode* &currentTree,SymbolTable* symtable) {
    Stack pStack;
    currentTree= new ExprTreeNode();
    ExprTreeNode* top = currentTree;
    pStack.push(currentTree);
    if (tokens.size()!=0){
        currentTree->id = ":=";
        currentTree->type = "equal";
        currentTree->left = new ExprTreeNode();
        currentTree->left->id = tokens[0];
        currentTree->left->type = "VAR";
        currentTree->right = new ExprTreeNode();
        currentTree = currentTree->right;
        vector<string> tokensU(tokens.begin()+2,tokens.end());
        for (const std::string& token : tokensU) {
            if (token == "(") {
                currentTree->left = new ExprTreeNode();
                pStack.push(currentTree);
                currentTree = currentTree->left;
            } else if (token == "+" || token == "-" || token == "*" || token == "/") {
                //cout<<"here"<<endl;
                currentTree->id = token;
                currentTree->right = new ExprTreeNode();
                if (token == "+"){
                    currentTree->type = "ADD";
                }else if (token == "-"){
                    currentTree->type = "SUB";
                }
                else if (token == "*"){
                    currentTree->type = "MUL";
                }
                else if (token == "/"){
                    currentTree->type = "DIV";
                }
                pStack.push(currentTree);
                currentTree = currentTree->right;
            } else if (token == ")") {
                currentTree = pStack.pop();
            } else if (token != "+" && token != "-" && token != "*" && token != "/" && token != ")") {
                if (isInteger(token)){
                    //cout<<"here";
                    
                 
                        UnlimitedInt* num = new UnlimitedInt(token);
                        UnlimitedInt* one = new UnlimitedInt("1");
                        UnlimitedRational* value = new UnlimitedRational(num,one);
                        currentTree->type = "VAL";
                        currentTree->id = token;
                        currentTree->val = value;
                        currentTree = pStack.pop();

                }else{
                    currentTree->type = "VAR";
                    currentTree->id = token;
                    currentTree->evaluated_value = symtable->search(token);
                    currentTree = pStack.pop();
                }

            }
        }
        //first_breath(eTree);
        top->left->evaluated_value = evalhelper(top->right);
        return;
    }else{
        top->left->evaluated_value = evalhelper(top->right);
        return;
    }
}
void Evaluator::parse(vector<string> code) {
    ExprTreeNode* root;
    //int i = 0;
    buildParseTree(code,root,symtable);
    expr_trees.push_back(root);
}


    // Evaluate the last element of the expr_trees
    // This function is guaranteed to be called immediately 
    // after a call to parse, and will be only called ONCE
    // for a tree
    // Also populate the symbol tables
    void Evaluator::eval(){
        int i=expr_trees.size()-1;
        ExprTreeNode* rootnode=expr_trees[i];
        UnlimitedRational* ans=evalhelper(rootnode->right);
        //cout<<"in eval after"<<endl;
        symtable->insert(rootnode->left->id,ans);
    }
