/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "exprtreenode.h"
ExprTreeNode::ExprTreeNode(){
    left = nullptr;
    right = nullptr;
    id = "";
    val = nullptr;
    evaluated_value = nullptr;

}
// id = ":=" for root type = equa 
//contents of node : string type;UnlimitedRational* val( for val );string id;
ExprTreeNode::ExprTreeNode(string t,UnlimitedInt* v){
    type = t;
    if (v != nullptr){
    UnlimitedInt* dummy = new UnlimitedInt("1");
    val = new UnlimitedRational(v,dummy);
    }else{
       val = nullptr;
    }
    

}
ExprTreeNode::ExprTreeNode(string t, UnlimitedRational* v){
    type = t;
    if (v != nullptr){
        val = v;
    }else{
        val = nullptr;
    }
}
ExprTreeNode::~ExprTreeNode(){
    left = nullptr;
    right = nullptr;
    delete val;
    delete evaluated_value;
}