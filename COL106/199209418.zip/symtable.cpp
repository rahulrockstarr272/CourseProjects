/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "symtable.h"
SymbolTable::SymbolTable(){
    size = 0;
    root = new SymEntry();         //n +2
}
SymbolTable::~SymbolTable(){
    size = 0;
    delete root;
}
int SymbolTable::get_size(){
    return size;
}
SymEntry* SymbolTable::get_root(){
    return root;
}
void SymbolTable::insert(string k, UnlimitedRational* v){    //error
    //push(root,k,v,size);
    //size++;
    if (size == 0){
        //SymEntry* curr = root;    //get_root()   old
        root->key = k;    //curr = new SymEntry(k,v)  old
        root->val = v;
        size = 1;
        return;
    }
    SymEntry* curr = root;    //get_root() old
    while (true){
        if (curr->key > k){
            if (curr->left != nullptr){
                curr = curr->left;
            }else{
                curr->left = new SymEntry(k,v);          //new SymEntry(k,v) old
                size++;
                return;                //return; old
            }
        }else{
            if (curr->right != nullptr){
                curr = curr->right;
            }else{
                curr->right = new SymEntry(k,v);
                size++;
                return;
            }
        }
    }
    //return;
}
UnlimitedRational* SymbolTable::search(string k){
    SymEntry* curr = get_root();
    while (curr != nullptr && curr->key != k){
        if (curr->key > k){
            curr = curr->left;
        }else{
            curr = curr->right;
        }
    }
    return curr->val;
}
//helper function for remove
SymEntry* findminval(SymEntry* r){
if(r==NULL)return r;
    while(r->left!=NULL){
        r=r->left;
    }
    return r;
}
SymEntry* deleteNode(SymEntry* &root, string k) {
    if (root == nullptr) {
        return nullptr;
    }
    if (root->key == k) {
        if (root->left == nullptr && root->right == nullptr) {
            delete root;
            return nullptr;
        }
        if (root->left != nullptr && root->right == nullptr) {
            SymEntry* temp = root->left;
            delete root;
            return temp;
        }
        if (root->right != nullptr && root->left == nullptr) {
            SymEntry* temp = root->right;
            delete root;
            return temp;
        }
        if (root->right != nullptr && root->left != nullptr) {
            string minimum = findminval(root->right)->key;
            root->key = minimum;
            root->right = deleteNode(root->right, minimum);
        }
    } else if (root->key > k) {
        root->left = deleteNode(root->left, k);
    } else {
        root->right = deleteNode(root->right, k);
    }
    return root;
}

 

void SymbolTable::remove(string k){
    deleteNode(root, k);
    size--;
}